include("raices.jl")

# Cálculo de la raíz
intervalo = (-3, -1)
#f(x) = exp(x) - 4 + x
#f(x) = x - 0.2 * sin(x) -0.5
#f(x) = exp(x/2)-x*x-3*x
#f(x) = exp(x)*cos(x)-x*x+3*x
#f(x) = 0.5*x*x*x+x*x-2*x-5
f(x) = exp(x)-4*x*x-8*x

tol = 1e-4
resultado = raices.biseccion(f, intervalo, tol)
resultado_2 = raices.falsaposicion(f,intervalo,tol)
try
    global resultado_3 = raices.puntofijo(f, intervalo[1], tol)
catch
    global resultado_3 = Dict("raiz" => "No encontrada", "error" => "N/A", "iteraciones" => 1000, "metodo" => "puntofijo")
end
resultado_4 = raices.newtonraphson(f,intervalo[1],tol)
resultado_5 = raices.vonmises(f,intervalo[1],tol)
resultado_6 = raices.secante(f,intervalo[1],intervalo[2],tol)

# Imprimir código LaTeX
println("\\[")
println("f(x) = \\exp(x) - 4 + x")
println("\\]")


println("$(resultado["metodo"]) & $(resultado["raiz"]) & $(resultado["iteraciones"]) \\\\")
println("$(resultado_2["metodo"]) & $(resultado_2["raiz"]) & $(resultado_2["iteraciones"]) \\\\")
println("$(resultado_3["metodo"]) & $(resultado_3["raiz"]) & $(resultado_3["iteraciones"]) \\\\")
println("$(resultado_4["metodo"]) & $(resultado_4["raiz"]) & $(resultado_4["iteraciones"]) \\\\")
println("$(resultado_5["metodo"]) & $(resultado_5["raiz"]) & $(resultado_5["iteraciones"]) \\\\")
println("$(resultado_6["metodo"]) & $(resultado_6["raiz"]) & $(resultado_6["iteraciones"]) \\\\")



