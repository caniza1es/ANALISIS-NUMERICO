
using Plots
include("raices.jl")
function vel(m,c,t,g)
    return (g*m)/c*(1-exp(-(c/m)*t))
end

intervalo = (50,60)

g=9.81
v=36
c=15
t=10
tol = 1e-4

mas = m -> 36 - (g*m)/c * (1-exp(-(c/m)*t))

resultado = raices.biseccion(mas, intervalo, tol)
resultado_2 = raices.falsaposicion(mas,intervalo,tol)

println("$(resultado["metodo"]) & $(resultado["raiz"]) & $(resultado["iteraciones"]) \\\\")
println("$(resultado_2["metodo"]) & $(resultado_2["raiz"]) & $(resultado_2["iteraciones"]) \\\\")
plot(mas, intervalo[1], intervalo[2], label = "Función mas", xlabel = "m", ylabel = "f(m)", title = "Gráfico intervalo", legend = :topleft)

savefig("funcion_mas_plot.png")

intervalo = (2,5)
m = 82
t=4
cr = c -> 36 - (g*m)/c * (1-exp(-(c/m)*t))

resultado = raices.biseccion(cr, intervalo, tol)
resultado_2 = raices.falsaposicion(cr,intervalo,tol)

println("$(resultado["metodo"]) & $(resultado["raiz"]) & $(resultado["iteraciones"]) \\\\")
println("$(resultado_2["metodo"]) & $(resultado_2["raiz"]) & $(resultado_2["iteraciones"]) \\\\")
plot(cr, intervalo[1], intervalo[2], label = "Función cr", xlabel = "c", ylabel = "f(c)", title = "Gráfico intervalo", legend = :topleft)

savefig("funcion_cr_plot.png")