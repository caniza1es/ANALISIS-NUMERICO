include("raices.jl")

f(x) = -2x^6-1.5x^4+10x+2
tol = 0.05
intervalo = (0,1)
resultado_3 = raices.puntofijo(f, intervalo[1], tol)
resultado_4 = raices.newtonraphson(f,1,tol)
resultado_6 = raices.secante(f,intervalo[1],intervalo[2],tol)
println("$(resultado_3["metodo"]) & $(resultado_3["raiz"]) & $(resultado_3["iteraciones"]) \\\\")
println("$(resultado_4["metodo"]) & $(resultado_4["raiz"]) & $(resultado_4["iteraciones"]) \\\\")
println("$(resultado_6["metodo"]) & $(resultado_6["raiz"]) & $(resultado_6["iteraciones"]) \\\\")
