include("splines.jl")

puntos = [1.6 2; 2 8; 2.5 14; 3.2 15; 4 8; 4.5 2]

A = splines.lagrange(puntos)

f(x) = A(x)

using Plots

scatter(puntos[:, 1], puntos[:, 2], label="Puntos", xlabel="x", ylabel="f(x)", legend=:bottomright)

plot!(f, extrema(puntos[:, 1])..., label="Interpolación de Lagrange")

savefig("interpolacion_lagrange.png")

print(A(2.8))