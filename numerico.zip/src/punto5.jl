include("splines.jl")

puntos = [3 2.5; 4.5 1.0; 7.0 2.5; 9.0 0.5]
A = splines.spline_cubico(puntos)

using Plots

scatter(puntos[:, 1], puntos[:, 2], label="Puntos", xlabel="x", ylabel="f(x)", legend=:bottomright)


x_min, x_max = extrema(puntos[:, 1])
x_vals = range(x_min, x_max, length=100)


y_vals = [A(x) for x in x_vals]


plot!(x_vals, y_vals, label="Spline cubico")


savefig("spline_1.png")


println(A(4))
println(A(2.25))
