function lagrange_interpolation(x_values, y_values, x_point)
    n = length(x_values)
    if x_point < x_values[1] || x_point > x_values[end]
        return "Error: El valor a estimar está fuera del rango de datos."
    end


    interval_index = findfirst(x -> x > x_point, x_values) - 1
    if interval_index == 0
        interval_index = 1
    elseif interval_index >= n - 1
        interval_index = n - 2
    end


    if interval_index == 1 || interval_index == n - 2

        selected_x = x_values[interval_index:interval_index+1]
        selected_y = y_values[interval_index:interval_index+1]
        degree = 2
    else

        selected_x = x_values[interval_index-1:interval_index+2]
        selected_y = y_values[interval_index-1:interval_index+2]
        degree = 3
    end


    lagrange_polynomial = 0
    for i in 1:degree
        product = selected_y[i]
        for j in 1:degree
            if j != i
                product *= (x_point - selected_x[j]) / (selected_x[i] - selected_x[j])
            end
        end
        lagrange_polynomial += product
    end

    return lagrange_polynomial
end

function generate_latex_table(x_values, y_values)
    x_points = collect(minimum(x_values):0.5:maximum(x_values)) 
    println("\\begin{table}[H]")
    println("\\centering")
    println("\\begin{tabular}{ccc}")
    println("\\hline")
    println("x & f(x) real & Estimación \\\\ \\hline")
    for x in x_points
        y_real = log(x) 
        y_estimated = lagrange_interpolation(x_values, y_values, x)
        if isa(y_estimated, String)
            println("$x & $y_real & Error \\\\")
        else
            println("$x & $y_real & $y_estimated \\\\")
        end
    end
    println("\\hline")
    println("\\end{tabular}")
    println("\\caption{Comparación de valores reales y estimados.}")
    println("\\end{table}")
end



x_values = 1:10
y_values = log.(x_values)  
x_point = 5.5  

estimated_y = lagrange_interpolation(x_values, y_values, x_point)
println("El valor estimado de y para x = $x_point es $estimated_y")

generate_latex_table(x_values, y_values)