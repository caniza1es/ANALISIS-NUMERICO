using Plots
include("splines.jl")

# Define the function
f(x) = 1 / (1 + 25x^2)

# Generate data points
xvals = [-1, 0.5, 0, 0.5, 1]
yvals = [f(i) for i in xvals]

# Create a matrix of x and y values
matrix = [xvals yvals]

# Evaluate the Lagrange function
lag = splines.lagrange(matrix)

# Generate a range of x values for plotting
x = range(-1, 1, length=400)

# Evaluate the Lagrange interpolation for the entire range of x values
lag_values = [lag(xi) for xi in xvals]

# Plot both the data points and the Lagrange interpolation
scatter(xvals, yvals, label="Data Points")
plot!(xvals, lag_values, label="Lagrange Interpolation")
savefig("plot_fx_with_lag.png")
