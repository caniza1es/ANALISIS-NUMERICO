module raices

export biseccion,falsaposicion,puntofijo,newtonraphson,vonmises,secante

    using ForwardDiff

    function biseccion(f, intervalo, err)
        a, b = intervalo
        iteraciones = 0
        
        if sign(f(a)) == sign(f(b))
            error("F(a) y F(b) no tienen signos opuestos")
        end
        
        while (b - a) / 2 > err
            c = (a + b) / 2
            if sign(f(a)) != sign(f(c))
                b = c
            elseif sign(f(b)) != sign(f(c))
                a = c
            end
            iteraciones += 1
        end

        return Dict("raiz" => (a + b) / 2, "error" => (b - a) / 2, "iteraciones" => iteraciones, "metodo" => "biseccion")
    end

    function falsaposicion(f, intervalo, error)
        a, b = intervalo
        iteraciones = 0  
        if sign(f(a)) == sign(f(b))
            error("F(a) y F(b) no tienen signos opuestos")
        end
        c = a 
        c_previo = a 
        error_relativo = Inf 
    
        while true
            c_previo = c
            c = b - f(b) * (b - a) / (f(b) - f(a))
            if iteraciones > 0
                error_relativo = abs(c - c_previo) / abs(c)
            end
            if  error_relativo < error
                break
            end
            if sign(f(a)) == sign(f(c))
                a = c
            else
                b = c
            end
            iteraciones += 1
        end
        return Dict("raiz" => c, "error" => error_relativo, "iteraciones" => iteraciones,"metodo" => "falsaposicion")
    end

    function puntofijo(g, x0, err)
        x = x0
        iteraciones = 0
        
        while true
            x_nuevo = g(x)
            iteraciones += 1
            
            if abs(x_nuevo - x) < err
                return Dict("raiz" => x_nuevo, "error" => abs(x_nuevo - x), "iteraciones" => iteraciones)
            end
            
            x = x_nuevo
            if iteraciones > 1000
                return Dict("raiz" => "No encontrada", "error" => "N/A", "iteraciones" => iteraciones, "metodo" => "puntofijo")
            end
        end
    end

    function newtonraphson(f, x0, tol)
        iteraciones = 0
        x = x0
        max_iter = 100
        while iteraciones < max_iter
            df = x -> ForwardDiff.derivative(f, x)  
            x_next = x - f(x) / df(x)  
            if abs(x_next - x) < tol  
                return Dict("raiz" => x_next, "error" => abs(x_next - x), "iteraciones" => iteraciones,"metodo" => "newtonraphson")
            end
            x = x_next  
            iteraciones += 1
        end
        Dict("raiz" => "No encontrada", "error" => "N/A", "iteraciones" => iteraciones,"metodo" => "newtonraphson")
    end
    function vonmises(f, x0, tol)
        iteraciones = 0
        x = x0
        max_iter = 100
        df = ForwardDiff.derivative(f, x0) 
        if df == 0
            error("Derivative at initial guess is zero.")
        end
        while iteraciones < max_iter
            f_val = f(x)  
            x_next = x - f_val / df  
            if abs(x_next - x) < tol   
                return Dict("raiz" => x_next, "error" => abs(x_next - x), "iteraciones" => iteraciones,"metodo" => "vonmises")
            end
            x = x_next  
            iteraciones += 1
        end
    
        return Dict("raiz" => "No encontrada", "error" => "N/A", "iteraciones" => iteraciones,"metodo" => "vonmises")
    end
    
    function secante(f, x0, x1,tol)
        iteraciones = 0
        x_prev = x0
        x = x1
        max_iter = 100
        while iteraciones < max_iter
            if f(x) - f(x_prev) == 0
                error("División por cero en el método de la secante")
            end
            x_next = x - f(x) * (x - x_prev) / (f(x) - f(x_prev))
            if abs(x_next - x) < tol
                return Dict("raiz" => x_next, "error" => abs(x_next - x), "iteraciones" => iteraciones + 1,"metodo" => "secante")
            end
            x_prev = x
            x = x_next
            iteraciones += 1
        end
        error("Máximo de iteraciones alcanzado sin convergencia")
    end
    
end 