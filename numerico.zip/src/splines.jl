module splines

export lagrange,spline_cubico

using Dierckx

function spline_cubico(puntos)
    x = puntos[:, 1]
    y = puntos[:, 2]
    spline = Spline1D(x, y, k=3) 
    return spline
end


function lagrange(points)
    function L(x)
        total_sum = 0.0
        n = size(points, 1) 
        for i in 1:n
            xi, yi = points[i, 1], points[i, 2]  
            li = 1.0
            for j in 1:n
                if j != i
                    xj, _ = points[j, 1], points[j, 2]
                    li *= (x - xj) / (xi - xj)
                end
            end
            total_sum += yi * li
        end
        return total_sum
    end
    return L
end



end