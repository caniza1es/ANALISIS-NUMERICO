import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import fsolve

# Define constants
g = 9.81

# Define the function velocidad_paracaidista
def velocidad_paracaidista(m, c=15.0, t=10.0):
    v = (g * m / c) * (1 - np.exp(-c / m * t))
    return v - 36.0

# Define the range of mass values to plot
mass_range = np.arange(50, 200, 0.5)

# Calculate velocity values for each mass
velocities = [velocidad_paracaidista(m) for m in mass_range]

# Plot the function
plt.figure()
plt.plot(mass_range, velocities, label="v - 36.0 vs. Mass")
plt.xlabel("Mass (m)")
plt.ylabel("v - 36.0")
plt.title("Velocity of a Parachutist")

# Allow resizing with the mouse
plt.gcf().set_size_inches(10, 6)  # Set initial size
plt.gcf().tight_layout()
plt.gcf().canvas.manager.set_window_title("Resizable Plot")  # Set window title
plt.gcf().canvas.manager.window.resizable(True, True)

plt.show()
